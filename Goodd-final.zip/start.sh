#!/bin/bash
source /opt/venv/bin/activate
python main.py
